function [ success_flag ] = draw_wall( nodeI, nodeJ, v_or, L, t, off_i, off_j, style, edges_color, filling_color )

% draws a wall defined by 2 nodes, an orientation vector equivalent to the
% one of opensees (geomTransf) parallel to the z axis (thickness) of the
% section. Two offsets can be specified. nodeI and nodeJ are the vector
% column of the 3 coordinates of I and J;

if nargin < 10
   filling_color='b';
end
if nargin < 9
   edges_color = 'k';
end

H_wall = norm(nodeJ-nodeI);
x_loc = (nodeJ-nodeI) / norm(nodeJ-nodeI);

% check if the orientation vector is right (it can't be parallel to the axis of the wall
if norm(v_or-(v_or'*x_loc)*x_loc)==0
    warning('Orientation vector parallel to the axis. The orientation vector is assumed parallel to the global Z (or global Y if this does not work');  
    v_or = [0;0;1];
    if norm(v_or-(v_or'*x_loc)*x_loc)==0
        v_or = [0;1;0];
    end
end
    
v_or_x = (v_or' * x_loc) * x_loc;
v_or_z = v_or - v_or_x;
z_loc = v_or_z / norm(v_or_z);
y_loc = cross(z_loc, x_loc);

%% wireframe view
if strcmp(style,'wireframe')
    % base
    verticesI_loc = [off_i(1),        off_i(1),       off_i(1),       off_i(1);
                     off_i(2)-L/2,    off_i(2)-L/2,   off_i(2)+L/2,   off_i(2)+L/2;
                     off_i(3)-t/2,    off_i(3)+t/2,   off_i(3)+t/2,   off_i(3)-t/2];
    for kCol=1:4
       verticesI(:,kCol) = verticesI_loc(1,kCol)*x_loc + verticesI_loc(2,kCol)*y_loc + verticesI_loc(3,kCol)*z_loc; 
    end
    % plot base I
    plot3([nodeI(1)+verticesI(1,1),nodeI(1)+verticesI(1,2)], [nodeI(2)+verticesI(2,1),nodeI(2)+verticesI(2,2)], [nodeI(3)+verticesI(3,1),nodeI(3)+verticesI(3,2)], '-', 'color', edges_color);     
    plot3([nodeI(1)+verticesI(1,2),nodeI(1)+verticesI(1,3)], [nodeI(2)+verticesI(2,2),nodeI(2)+verticesI(2,3)], [nodeI(3)+verticesI(3,2),nodeI(3)+verticesI(3,3)], '-', 'color', edges_color);
    plot3([nodeI(1)+verticesI(1,3),nodeI(1)+verticesI(1,4)], [nodeI(2)+verticesI(2,3),nodeI(2)+verticesI(2,4)], [nodeI(3)+verticesI(3,3),nodeI(3)+verticesI(3,4)], '-', 'color', edges_color);
    plot3([nodeI(1)+verticesI(1,4),nodeI(1)+verticesI(1,1)], [nodeI(2)+verticesI(2,4),nodeI(2)+verticesI(2,1)], [nodeI(3)+verticesI(3,4),nodeI(3)+verticesI(3,1)], '-', 'color', edges_color);

    verticesJ_loc = [H_wall+off_j(1), H_wall+off_j(1), H_wall+off_j(1), H_wall+off_j(1);
                     off_j(2)-L/2,    off_j(2)-L/2,    off_j(2)+L/2,    off_j(2)+L/2;
                     off_j(3)-t/2,    off_j(3)+t/2,    off_j(3)+t/2,    off_j(3)-t/2];

    for kCol=1:4
       verticesJ(:,kCol) = verticesJ_loc(1,kCol)*x_loc + verticesJ_loc(2,kCol)*y_loc + verticesJ_loc(3,kCol)*z_loc; 
    end
    % plot base J
    plot3([nodeI(1)+verticesJ(1,1),nodeI(1)+verticesJ(1,2)], [nodeI(2)+verticesJ(2,1),nodeI(2)+verticesJ(2,2)], [nodeI(3)+verticesJ(3,1),nodeI(3)+verticesJ(3,2)], '-', 'color', edges_color);    
    plot3([nodeI(1)+verticesJ(1,2),nodeI(1)+verticesJ(1,3)], [nodeI(2)+verticesJ(2,2),nodeI(2)+verticesJ(2,3)], [nodeI(3)+verticesJ(3,2),nodeI(3)+verticesJ(3,3)], '-', 'color', edges_color);  
    plot3([nodeI(1)+verticesJ(1,3),nodeI(1)+verticesJ(1,4)], [nodeI(2)+verticesJ(2,3),nodeI(2)+verticesJ(2,4)], [nodeI(3)+verticesJ(3,3),nodeI(3)+verticesJ(3,4)], '-', 'color', edges_color); 
    plot3([nodeI(1)+verticesJ(1,4),nodeI(1)+verticesJ(1,1)], [nodeI(2)+verticesJ(2,4),nodeI(2)+verticesJ(2,1)], [nodeI(3)+verticesJ(3,4),nodeI(3)+verticesJ(3,1)], '-', 'color', edges_color);  

    % plot other edges
    plot3([nodeI(1)+verticesI(1,1),nodeI(1)+verticesJ(1,1)], [nodeI(2)+verticesI(2,1),nodeI(2)+verticesJ(2,1)], [nodeI(3)+verticesI(3,1),nodeI(3)+verticesJ(3,1)], '-', 'color', edges_color); 
    plot3([nodeI(1)+verticesI(1,2),nodeI(1)+verticesJ(1,2)], [nodeI(2)+verticesI(2,2),nodeI(2)+verticesJ(2,2)], [nodeI(3)+verticesI(3,2),nodeI(3)+verticesJ(3,2)], '-', 'color', edges_color); 
    plot3([nodeI(1)+verticesI(1,3),nodeI(1)+verticesJ(1,3)], [nodeI(2)+verticesI(2,3),nodeI(2)+verticesJ(2,3)], [nodeI(3)+verticesI(3,3),nodeI(3)+verticesJ(3,3)], '-', 'color', edges_color);
    plot3([nodeI(1)+verticesI(1,4),nodeI(1)+verticesJ(1,4)], [nodeI(2)+verticesI(2,4),nodeI(2)+verticesJ(2,4)], [nodeI(3)+verticesI(3,4),nodeI(3)+verticesJ(3,4)], '-', 'color', edges_color);  
else
    %% frame view
  if strcmp(style,'frame')
    % base
    verticesI_loc = [off_i(1); off_i(2); off_i(3)];
    verticesJ_loc = [H_wall+off_j(1); off_j(2); off_j(3)];
    for kCol=1:1
       verticesI(:,kCol) = verticesI_loc(1,kCol)*x_loc + verticesI_loc(2,kCol)*y_loc + verticesI_loc(3,kCol)*z_loc; 
    end
    for kCol=1:1
       verticesJ(:,kCol) = verticesJ_loc(1,kCol)*x_loc + verticesJ_loc(2,kCol)*y_loc + verticesJ_loc(3,kCol)*z_loc; 
    end
    % plot axis
    plot3([nodeI(1)+verticesI(1,1),nodeI(1)+verticesJ(1,1)], [nodeI(2)+verticesI(2,1),nodeI(2)+verticesJ(2,1)], [nodeI(3)+verticesI(3,1),nodeI(3)+verticesJ(3,1)], '-', 'color', edges_color);   
    
  else
    %% full shape view
    % base
    verticesI_loc = [off_i(1),        off_i(1),       off_i(1),       off_i(1);
                     off_i(2)-L/2,    off_i(2)-L/2,   off_i(2)+L/2,   off_i(2)+L/2;
                     off_i(3)-t/2,    off_i(3)+t/2,   off_i(3)+t/2,   off_i(3)-t/2];
    for kCol=1:4
       verticesI(:,kCol) = verticesI_loc(1,kCol)*x_loc + verticesI_loc(2,kCol)*y_loc + verticesI_loc(3,kCol)*z_loc; 
    end
    % plot base I
    h=patch(nodeI(1)+verticesI(1,:),nodeI(2)+verticesI(2,:),nodeI(3)+verticesI(3,:), filling_color);
    set(h,'edgecolor', edges_color);

    verticesJ_loc = [H_wall+off_j(1), H_wall+off_j(1), H_wall+off_j(1), H_wall+off_j(1);
                     off_j(2)-L/2,    off_j(2)-L/2,    off_j(2)+L/2,    off_j(2)+L/2;
                     off_j(3)-t/2,    off_j(3)+t/2,    off_j(3)+t/2,    off_j(3)-t/2];

    for kCol=1:4
       verticesJ(:,kCol) = verticesJ_loc(1,kCol)*x_loc + verticesJ_loc(2,kCol)*y_loc + verticesJ_loc(3,kCol)*z_loc; 
    end
    % plot base J
    h=patch(nodeI(1)+verticesJ(1,:),nodeI(2)+verticesJ(2,:),nodeI(3)+verticesJ(3,:), filling_color);
    set(h,'edgecolor', edges_color);

    % plot other edges
    corners = [1,2];
    h=patch(nodeI(1)+[verticesI(1,corners(1)), verticesI(1,corners(2)), verticesJ(1,corners(2)), verticesJ(1,corners(1))], ...
            nodeI(2)+[verticesI(2,corners(1)), verticesI(2,corners(2)), verticesJ(2,corners(2)), verticesJ(2,corners(1))], ...
            nodeI(3)+[verticesI(3,corners(1)), verticesI(3,corners(2)), verticesJ(3,corners(2)), verticesJ(3,corners(1))], filling_color);
    set(h,'edgecolor', edges_color);
    
    corners = [2,3];
    h=patch(nodeI(1)+[verticesI(1,corners(1)), verticesI(1,corners(2)), verticesJ(1,corners(2)), verticesJ(1,corners(1))], ...
            nodeI(2)+[verticesI(2,corners(1)), verticesI(2,corners(2)), verticesJ(2,corners(2)), verticesJ(2,corners(1))], ...
            nodeI(3)+[verticesI(3,corners(1)), verticesI(3,corners(2)), verticesJ(3,corners(2)), verticesJ(3,corners(1))],  filling_color);
    set(h,'edgecolor', edges_color);
    
    corners = [3,4];
    h=patch(nodeI(1)+[verticesI(1,corners(1)), verticesI(1,corners(2)), verticesJ(1,corners(2)), verticesJ(1,corners(1))], ...
            nodeI(2)+[verticesI(2,corners(1)), verticesI(2,corners(2)), verticesJ(2,corners(2)), verticesJ(2,corners(1))], ...
            nodeI(3)+[verticesI(3,corners(1)), verticesI(3,corners(2)), verticesJ(3,corners(2)), verticesJ(3,corners(1))], filling_color);
    set(h,'edgecolor', edges_color);
    
    corners = [4,1];
    h=patch(nodeI(1)+[verticesI(1,corners(1)), verticesI(1,corners(2)), verticesJ(1,corners(2)), verticesJ(1,corners(1))], ...
            nodeI(2)+[verticesI(2,corners(1)), verticesI(2,corners(2)), verticesJ(2,corners(2)), verticesJ(2,corners(1))], ...
            nodeI(3)+[verticesI(3,corners(1)), verticesI(3,corners(2)), verticesJ(3,corners(2)), verticesJ(3,corners(1))], filling_color);
    set(h,'edgecolor', edges_color);
    
  end
end
success_flag = 1;



end


