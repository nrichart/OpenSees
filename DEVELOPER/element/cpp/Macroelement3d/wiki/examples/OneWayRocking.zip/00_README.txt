ONE-WAY ROCKING, FREE VIBRATIONS

This folder contains the input files to perform a free-vibration analysis of a facade subjected
to an initial out-of-plane displacement. The facade is connected to two side walls by means of
zero-length elements whcih can fail in tension.

Contents:
OneWayRocking_freeVibrations.tcl:   OpenSees input file
zeroAccelerogram.txt:               null accelerogram used for free vibrations analysis
modelFacade.mat:                    matlab variable containing the model geometry
modelScheme.jpg:                    model scheme (nodes, elements, local axes orientations)
Postprocessing.m:                   Matlab script used to read results and produce deformed shape plots
plot_functions/:                    folder containing matlab functions used for graphical output.

In order to perform and postprocess the anaylsis:
1. Download and install OpenSees and put the libraries "Macroelement3d.dll" and "TensionDamage1d.dll"
   in the same folder.
2. Run OpenSees with the provided input file "OneWayRocking_freeVibrations.tcl" (it takes a few seconds)
3. Open the matlab script "postprocessing.m" (Matlab R2017b was used)
4. Change the variable resultsPath (line 9) with the path in which the output files were created
   (the path of the folder containing OpenSees and the libraries)
5. Run the script