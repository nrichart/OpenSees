clear all
close all
clc

% path of the folder containing the results files produced by OpenSees
resultsPath = '../../../04_analyses/'; 

% path of plot functions
addpath('plot_functions');

load('modelFacade.mat');

%% read results
nNodes = length(model.node);
formatSpec = '%f';
for k=1:nNodes
    formatSpec = [formatSpec, '%f%f%f%f%f%f'];
end
formatSpec = [formatSpec, '%[^\n\r]'];

% import all node displ
filename = [resultsPath,'AllDispl.out'];
fileID = fopen(filename,'r');
dataArray = textscan(fileID, formatSpec, 'Delimiter', ' ', 'MultipleDelimsAsOne', true,  'ReturnOnError', false);
fclose(fileID);
for kNode=1:nNodes
    result.node(kNode).u    = dataArray{:, (kNode-1)*6+ 2};
    result.node(kNode).v    = dataArray{:, (kNode-1)*6+ 3};
    result.node(kNode).w    = dataArray{:, (kNode-1)*6+ 4};
    result.node(kNode).rotx = dataArray{:, (kNode-1)*6+ 5};
    result.node(kNode).roty = dataArray{:, (kNode-1)*6+ 6};
    result.node(kNode).rotz = dataArray{:, (kNode-1)*6+ 7};
end

clearvars filename fileID dataArray ans;

% import all reaction forces
filename = [resultsPath,'AllReactions.out'];
fileID = fopen(filename,'r');
dataArray = textscan(fileID, formatSpec, 'Delimiter', ' ', 'MultipleDelimsAsOne', true,  'ReturnOnError', false);
fclose(fileID);

for time = 1:length(result.node(kNode).u)
    for k=1:nNodes
        kNode = k;
        result.node(kNode).Fx(time) = dataArray{:, (k-1)*6+ 2}(time);
        result.node(kNode).Fy(time) = dataArray{:, (k-1)*6+ 3}(time);
        result.node(kNode).Fz(time) = dataArray{:, (k-1)*6+ 4}(time);
        result.node(kNode).Mx(time) = dataArray{:, (k-1)*6+ 5}(time);
        result.node(kNode).My(time) = dataArray{:, (k-1)*6+ 6}(time);
        result.node(kNode).Mz(time) = dataArray{:, (k-1)*6+ 7}(time);
    end
end

baseNodes = [1,4,7];
Rx = zeros(size(result.node(1).Fx));
Ry = zeros(size(result.node(1).Fx));
Rz = zeros(size(result.node(1).Fx));

for k=1:length(baseNodes)
    kNode = baseNodes(k);
    Rx = Rx + result.node(kNode).Fx;
    Ry = Ry + result.node(kNode).Fy;
    Rz = Rz + result.node(kNode).Fz;
end



%% plot analysis
deformedTrue = 2;

kfig = 1;
fig1 = figure; hold on;
set(gcf,'Units','Centimeters');
set(gcf,'Position',[3 + 11*(kfig-1) 10 10 10]);
set(gcf,'PaperPositionMode','auto');
set(gca, 'projection', 'perspective');
light
set(gca, 'xlim', [  -1   5]);
set(gca, 'ylim', [  0   3]);
axis equal
axis manual
axis off

kfig =2;
fig2 = figure; hold on;
set(gcf,'Units','Centimeters');
set(gcf,'Position',[3 + 11*(kfig-1) 10 10 10]);
set(gcf,'PaperPositionMode','auto');


for time = 1:5:length(result.node(1).u)
    set(0, 'currentfigure', fig1);
    deformed = deformedTrue;
    cla
    drawModel(model, result, 'ColorPiers', 'none', 'ColorSpandrels', 'none');
    hold on
    drawModel(model, result,'styleNodes', 'sk', 'ColorPiers', [0.8 0 0], 'ColorSpandrels', [0 0 0.8], 'step', time, 'deformed', deformed, 'walls', [1,2,3,4,5,6],'styleNodes', 'sk');

    view([+20, 30]);
    
   
    set(gca, 'xlim', [  -1   5]);
    set(gca, 'ylim', [  0   3]);
    
    if time==1
        xlim = get(gca,'xlim');
        ylim = get(gca,'ylim');
        zlim = get(gca,'zlim');
    end
    
    set(gca, 'xlim', xlim);
    set(gca, 'ylim', ylim);
    set(gca, 'zlim', zlim);

    axis equal
    axis manual
    axis off 
        
    set(0, 'currentfigure', fig2);
    plot(result.node(3).u , '-k', 'color', [1 1 1]*0.5);
    hold on
    plot(result.node(3).u(1:time) , '-r', 'color', [1 0 0]*0.8);
    hold off

    drawnow  
end
