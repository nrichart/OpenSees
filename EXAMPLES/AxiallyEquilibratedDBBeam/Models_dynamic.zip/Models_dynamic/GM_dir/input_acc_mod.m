% this file increases or diminishes the number of points in an acceleration history
% useful if an analysis time step different than the real time ste is
% desired.
clear
clc
close

% INPUT PARAMETERS TO BE DEFINED
input_filename='GM_5_conc.AT2'; % input file containing one value of acceleration per line
dt_inp=0.00390625;
t_inp_tot=310;
N=10; %Number of points to be added
output_filename='GM_5_conc_mod.AT2'; % input file containing one value of acceleration per line

acc_inp=load(input_filename); % rerad numerical values and store them in vector acc_inp

% acc_inp(4:end)=[];


acc_out=[];
acc_out(1)=acc_inp(1);



for i=1:length(acc_inp)-1
  fava=linspace( acc_inp(i),acc_inp(i+1),N)'; 
  acc_out=[acc_out; fava(2:end)];
end

dt_out=t_inp_tot/length(acc_out)

fileID = fopen(output_filename,'w');
fprintf(fileID,'%f\n',acc_out);
fclose(fileID);